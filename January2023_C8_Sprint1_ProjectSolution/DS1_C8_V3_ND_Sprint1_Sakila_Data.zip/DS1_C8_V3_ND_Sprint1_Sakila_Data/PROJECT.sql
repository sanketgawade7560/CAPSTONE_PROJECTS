-- Task 1: Display the full names of actors available in the database.
use sakila;
select CONCAT(first_name, ' ', last_name) AS full_name
FROM actor;

-- Task 2: Management wants to know if there are any names of the actors appearing frequently.
-- (i)Display the number of times each first name appears in the database.
select first_name, COUNT(*) AS name_count
from actor
group by first_name
order by name_count DESC;

-- (ii) What is the count of actors that have unique first names in the database? Display the first names of all these actors.
select first_name
from actor
group by first_name
having COUNT(*) = 1;

-- Task 3: The management is interested to analyze the similarity in the last names of the actors.
-- (i) Display the number of times each last name appears in the database.
select last_name, COUNT(*) AS name_count
from actor
group by last_name
order by name_count DESC;

-- (ii)Display all unique last names in the database.
select DISTINCT last_name
from actor;

-- Task 4: The management wants to analyze the movies based on their ratings to determine if they are suitable for kids or some parental assistance is required. 
-- Perform the following tasks to perform the required analysis
-- (i) Display the list of records for the movies with the rating "R". (The movies with the rating "R" are not suitable for audience under 17 years of age).
select film_id, title, rating
from film
where rating = 'R';

-- (ii) Display the list of records for the movies that are not rated "R"
select film_id, title, rating
from film
Where rating != 'R';

-- (iii)Display the list of records for the movies that are suitable for audience below 13 years of age.
select film_id, title, rating
from film
where rating in ('G', 'PG');

-- Task 5: The board members want to understand the replacement cost of a movie copy(disc - DVD/Blue Ray). 
-- The replacement cost refers to the amount charged to the customer if the movie disc is not returned or is returned in a damaged state.
-- (i) Display the list of records for the movies where the replacement cost is up to $11.
select film_id, title, replacement_cost
from film
where replacement_cost <= 11.00;

-- (ii) Display the list of records for the movies where the replacement cost is between $11 and $20.
select film_id, title, replacement_cost
from film
Where replacement_cost > 11.00 and replacement_cost <= 20.00;

-- (iii) Display the list of records for the all movies in descending order of their replacement costs.
select film_id, title, replacement_cost
from film
order by replacement_cost DESC;

-- Task 6: Display the names of the top 3 movies with the greatest number of actors.
select film.title, COUNT(film_actor.actor_id) as actor_count
from film
join film_actor on film.film_id = film_actor.film_id
group by film.title
order by actor_count DESC
limit  3;

-- Task 7: 'Music of Queen' and 'Kris Kristofferson' have seen an unlikely resurgence. As an unintended consequence, films starting with the letters K' and Q' have also soared in popularity. 
-- Display the titles of the movies starting with the letters 'K' and Q

select title
from film
where title like 'K%' or title like 'Q%'
order by title;

-- Task 8: The film 'Agent Truman has been a great success. Display the names of all actors who appeared in this film.

select actor.first_name, actor.last_name
from actor
join film_actor on actor.actor_id = film_actor.actor_id
join film on film_actor.film_id = film.film_id
where film.title = 'Agent Truman';

-- Task 9: Sales have been lagging among young families, so the management wants to promote family movies. Identify all the movies categorized as family films.
select film.title, category.name AS category_name
from film
join film_category on film.film_id = film_category.film_id
join category on film_category.category_id = category.category_id
where category.name = 'Family'
order by film.title;

-- Task 10: The management wants to observe the rental rates and rental frequencies (Number of time the movie disc is rented).
-- (i) 	Display the maximum, minimum, and average rental rates of movies based on their ratings. The output must be sorted in descending order of the average rental rates.

select rating,
       max(rental_rate) AS max_rental_rate,
       min(rental_rate) AS min_rental_rate,
       avg(rental_rate) AS avg_rental_rate
from film
group by rating
order by avg_rental_rate DESC;
-- (ii) Display the movies in descending order of their rental frequencies, so the management can maintain more copies of those movies.
select film.title,
       COUNT(rental.rental_id) AS rental_count
from	 film
LEFT JOIN inventory ON film.film_id = inventory.film_id
LEFT JOIN rental ON inventory.inventory_id = rental.inventory_id
GROUP BY film.title
ORDER BY rental_count DESC;

-- Task 11: In how many film categories, the difference between the average film replacement cost ((disc - DVD/Blue Ray)
--  and the average film rental rate is greater than $15?
-- (i) Display the list of all film categories identified above, along with the corresponding average film replacement cost and average film rental rate.

SELECT category.name AS category_name,
       AVG(film.replacement_cost) AS avg_replacement_cost,
       AVG(film.rental_rate) AS avg_rental_rate,
       (AVG(film.replacement_cost) - AVG(film.rental_rate)) AS cost_rental_difference
FROM film
JOIN film_category ON film.film_id = film_category.film_id
JOIN category ON film_category.category_id = category.category_id
GROUP BY category.name
HAVING cost_rental_difference > 15
ORDER BY cost_rental_difference DESC;

-- Task 12: Display the film categories in which the number of movies is greater than 70.
SELECT category.name AS category_name, COUNT(film.film_id) AS movie_count
FROM category
JOIN film_category ON category.category_id = film_category.category_id
JOIN film ON film_category.film_id = film.film_id
GROUP BY category.name
HAVING COUNT(film.film_id) > 70;

-------------------------------- *************** END *************** -----------------------------------------------------------





















